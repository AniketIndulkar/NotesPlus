package com.notes.android.settings;

public interface SettingsView {

    void setFontSize(int fontSize);

    void setSortType(String sortType);

}
